# Independent re-extraction check, 2026-11-27 (v3.2.1)

What: an adversarial fact-check of the published panel (data/analysis/dirs_county_day.csv, v3.2.1) against the FCC
source documents, done WITHOUT the project's parsing code. Performed by an AI review agent (not a human keyer)
during an external review; scripts and outputs are included so the check can be rerun and audited.

Method
- Own extractor: pdftotext -layout text of each PDF in data/input/dirs/, table rows matched by regex, county names
  split across lines rebuilt from neighbouring lines (scripts/parse.py, scripts/full.py).
- Whole-panel comparison: all 10,051 rows, fields served, out, percent, damage, transport, power, backup, blanks.
  Result: 0 mismatches (95% upper bound 0.037% of rows). The full comparison table (fullcmp.csv, ~10 MB) is not
  included; rerun scripts/full.py to regenerate.
- Stratified random sample: numpy seed 20261127, 164 rows (era x report format; 100 hard cases: wrapped names,
  later pages of multi-page tables, punctuation, combined-storm reports), checked against the FCC .txt files
  (UTF-16, no BOM, for 2018-2020) or the PDF where the .txt is an FCC "not found" page (txt404.lst).
  Result: 0 mismatches in 1,286 fields (95% upper bounds 2.2% rows, 0.29% fields). sample.csv, sample_txt2.csv.
- FIPS: 1,183 state-county pairs checked against Census national_county2020.txt (scripts/fips.py): 0 mismatches.
- Coverage: 6 reports drawn with the same seed; 0 rows missing or extra.
- Wrapped-name rows: wrapcmp.csv.

Findings about exclusions (see the review): DOC-366519A1, DOC-366524A1, DOC-366526A1 (Laura 8/28-8/30) and
DOC-406197A1 (Helene 10/4) are legible in the source; their exclusion reasons come from the project's checker
(split county names; backquoted names such as Prince George`s), not FCC errors. DOC-406144A1 (Helene 10/3) is a
one-cell FCC total misprint, treated differently from Harvey's.

Caveat: this is an independent code path and an independent reviewer, but not a human double-keyed sample.
A human-keyed sample is still planned for the data descriptor.

Path edit (2026-11-27, when the archive was published with the data repository): in `scripts/`, the reviewer's absolute file paths were made relative. The repository root prefix became nothing (so `data/analysis/dirs_county_day.csv` is read from the repository root) and the work folder `/tmp/fc/` became `fc/`. Nothing else in the archive was changed. Run the scripts from the repository root, after writing pdftotext -layout text of each report to `fc/txt/<DOC>.layout.txt`.
