import json, pandas as pd, sys, re
rows=json.load(open('fc/rows.json'))
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str)
norm=lambda s: re.sub(r'[^A-Z]','',s.upper().replace('COUNTY','').replace('PARISH',''))
for d in sys.argv[1:]:
    mine={(r['state'],norm(r['county'])) for r in rows if r['doc']==d}
    pan={(r.state,norm(r.county)) for r in p[p.doc_id==d].itertuples()}
    print(d,'panel-only',sorted(pan-mine)[:20],'mine-only(study)',[x for x in sorted(mine-pan) if x[0] in set(p.state)][:20])
