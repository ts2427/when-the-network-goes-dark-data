import json,re,collections
rows=json.load(open('fc/rows.json'))
first={}
for r in rows:
    first.setdefault(r['doc'],r)
res=collections.Counter()
for d,r in first.items():
    L=open(f'fc/txt/{d}.layout.txt',errors='replace').read().split('\n')
    blk=L[max(0,r['line']-16):r['line']-1]
    # column-position ordering: find x position of keywords
    pos={}
    for l in blk:
        for k,pat in [('served','Served'),('out','Out'),('pct','Percent'),('D','Damage'),('T','Transport'),('P','Power'),('B','Back')]:
            m=re.search(pat,l)
            if m and k not in pos: pos[k]=m.start()
    order=''.join(k[0] for k,_ in sorted(pos.items(),key=lambda x:x[1]))
    res[(order,len(r['nums']))]+=1
    if 'D' in pos and not (pos['D']<pos['T']<pos['P']): print('ODD',d,pos)
print(res)
