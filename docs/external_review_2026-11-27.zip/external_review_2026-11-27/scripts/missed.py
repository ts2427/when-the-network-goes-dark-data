import json,re,pandas as pd,collections
rows=json.load(open('fc/rows2.json'))
cap=collections.defaultdict(set)
for r in rows: cap[r['doc']].add(r['line'])
w=pd.read_csv('fc/wrapcmp.csv',dtype=str)
man=pd.read_csv('code/manifest/dirs_reports.csv',dtype=str)
print(man.status.value_counts())
NUMT=r'(?:[\d,]+(?:\.\d+)?%?|N/A)'
cnt=collections.Counter()
for d in man.doc_id:
    L=open(f'fc/txt/{d}.layout.txt',errors='replace').read().replace('\f','').split('\n')
    for i,l in enumerate(L):
        if (i+1) in cap[d]: continue
        if re.match(r'^(.*?)\s+(%s(?:\s+%s){2,})\s*$'%(NUMT,NUMT),l) and '%' in l:
            s=l.strip()
            if re.match(r'(?i)^(total|state total)',s): continue
            cnt[re.sub(r'\d','N',re.sub(r'\s+',' ',s))[:30]]+=1
            if not re.match(r'^(PR|VI|AR|Puerto|N N)',s): print(d,i+1,s[:110])
