import pandas as pd, re
S=pd.read_csv('fc/sample.csv',dtype=str,keep_default_na=False)
def numpat(v):
    v=int(float(v)); s=f'{v:,}'
    return '(?:%s|%s)'%(re.escape(s),v)
def pctpat(v):
    f=float(v)
    c={f'{f:.1f}',f'{f:.2f}',f'{f:g}',f'{f:.0f}' if f==int(f) else 'XX', '0' if f==0 else 'XX','100' if f==100 else 'XX', f'{f:.2f}'.rstrip('0').rstrip('.') }
    return '(?:%s)%%'%'|'.join(re.escape(x) for x in c if x!='XX')
out=[]
cache={}
for r in S.itertuples():
    if r.doc_id not in cache:
        b=open(f'data/input/dirs/{r.doc_id}.txt','rb').read()
        t=b.decode('utf-16-le',errors='replace') if b[1:2]==b'\x00' else b.decode('utf-8',errors='replace')
        cache[r.doc_id]=re.sub(r'\s+',' ',t)
    T=cache[r.doc_id]
    name=r'\s*'.join(re.escape(ch) for ch in re.sub(r'\s+','',r.county))
    seq=[numpat(r.sites_served)]
    if r.fmt=='two_day': seq+=[r'[\d,]+',r'[\d.]+%']
    seq+=[numpat(r.sites_out),pctpat(r.pct_out)]
    for c in ['out_damage','out_transport','out_power','on_backup_power']:
        v=getattr(r,c)
        if v!='': seq.append(numpat(v))
    pat=name+r'\s*(?:County|Parish)?\s*'+r'\s*'.join(seq)+r'(?!\d)'
    m=re.search(pat,T,re.I)
    out.append(dict(rowid=r.rowid,doc=r.doc_id,county=r.county,txt_match=bool(m),snippet=m.group(0) if m else ''))
O=pd.DataFrame(out); O.to_csv('fc/sample_txt.csv',index=False)
print(O.txt_match.value_counts()); print(O[~O.txt_match][['doc','county']].to_string())
