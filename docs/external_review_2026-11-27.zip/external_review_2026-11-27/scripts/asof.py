import re,pandas as pd,datetime as dt
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str,keep_default_na=False)
d=p.drop_duplicates('doc_id')[['doc_id','storm','report_date','as_of_utc','as_of_imputed']]
OFF={'EDT':4,'EST':5,'CDT':5,'CST':6,'ET':4,'CT':5,'AST':4}
rows=[]
for r in d.itertuples():
    t=re.sub(r'\s+',' ',open(f'fc/txt/{r.doc_id}.layout.txt',errors='replace').read())
    m=re.search(r'as of (?:\w+day, )?([A-Z][a-z]+\.? \d{1,2}, \d{4}),? (?:at )?(\d{1,2}(?::\d{2})?) ?([ap])\.?m\.? ?\(?([A-Z]{2,3})?',t)
    if not m:
        m2=re.search(r'as of ([^.]{0,80})',t); rows.append((r.doc_id,r.storm,r.report_date,r.as_of_utc,r.as_of_imputed,'NOPARSE',m2.group(1)[:60] if m2 else '')); continue
    date=dt.datetime.strptime(m[1].replace('.',''),'%B %d, %Y') if '.' not in m[1] else None
    hh,mm=(m[2].split(':')+['0'])[:2]; h=int(hh)%12+(12 if m[3]=='p' else 0)
    tz=m[4] or '?'
    utc=(date+dt.timedelta(hours=h+OFF.get(tz,0),minutes=int(mm))) if date else None
    mine=utc.strftime('%Y-%m-%d %H:%M') if utc else '?'
    ok=r.as_of_utc.startswith(mine)
    rows.append((r.doc_id,r.storm,r.report_date,r.as_of_utc,r.as_of_imputed,f'{m[1]} {m[2]}{m[3]}m {tz}',mine if not ok else 'OK'))
R=pd.DataFrame(rows,columns=['doc','storm','date','as_of_utc','imputed','printed','check'])
print(R.check.eq('OK').sum(),len(R)); print(R[R.check!='OK'].to_string())
