import pandas as pd, numpy as np, json, re
SEED=20261127
rng=np.random.default_rng(SEED)
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str,keep_default_na=False)
p['rowid']=range(len(p))
yr=p.report_date.str[:4].astype(int)
p['era']=np.select([yr<=2018,yr<=2021,yr<=2024],['2017-18','2019-21','2022-24'],'2026')
p['fmt']=np.where(p.doc_id.isin(['DOC-346478A1','DOC-346482A1','DOC-346499A1']),'two_day',
         np.where(p.doc_id=='DOC-404487A1','no_state_col',
         np.where(p.out_power=='','no_cause',np.where(p.on_backup_power=='','cause','cause_backup'))))
mine=json.load(open('fc/mine.json'))
w=pd.read_csv('fc/wrapcmp.csv',dtype=str)
wrapped=set(zip(w.doc,w.county))
p['wrapped']=[(d,c) in wrapped for d,c in zip(p.doc_id,p.county)]
# first table page per doc
norm=lambda s: re.sub(r'[^A-Z]','',s.upper())
pages={}
for k,v in mine.items():
    d,s,c=k.split('|'); pages[(d,s,c)]=v['page']
p['page']=[pages.get((d,s,norm(c))) for d,s,c in zip(p.doc_id,p.state,p.county)]
fp=p.groupby('doc_id').page.transform('min')
p['contpage']=p.page>fp
p['hard']=(p.wrapped|p.county.str.contains(r"[.'`/-]| CITY|DESOTO|DE SOTO|ST ",case=False,regex=True)|
           p.doc_id.isin(['DOC-366394A1','DOC-375778A1','DOC-375808A1'])|(p.fmt.isin(['two_day','no_state_col'])))
picks=[]
# base: per era x fmt, n=6 each (or all if fewer)
for (e,f),g in p.groupby(['era','fmt']):
    n=min(len(g),12); picks+=list(rng.choice(g.rowid.values,n,replace=False))
# continuation-page rows: 15
g=p[p.contpage&~p.rowid.isin(picks)]; picks+=list(rng.choice(g.rowid.values,15,replace=False))
g=p[p.wrapped&~p.rowid.isin(picks)]; picks+=list(rng.choice(g.rowid.values,15,replace=False))
# hard cases: 50
g=p[p.hard&~p.rowid.isin(picks)]; picks+=list(rng.choice(g.rowid.values,50,replace=False))
S=p[p.rowid.isin(picks)].copy()
S.to_csv('fc/sample.csv',index=False)
print(len(S)); print(S.groupby(['era','fmt']).size()); print('hard',S.hard.sum(),'wrapped',S.wrapped.sum(),'contpage',S.contpage.sum())
print(p.groupby(['era','fmt']).size())
