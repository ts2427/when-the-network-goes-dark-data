import re, sys, glob, os, json, csv
ST = {'AL':'Alabama','FL':'Florida','GA':'Georgia','LA':'Louisiana','MS':'Mississippi','NC':'North Carolina',
      'SC':'South Carolina','TN':'Tennessee','TX':'Texas','VA':'Virginia'}
OTHER = 'AR|PR|VI|MD|DE|NJ|NY|PA|WV|KY|OH|IN|IL|MO|OK|DC|CT|MA|RI|NH|VT|ME|IA'
full = '|'.join(ST.values())
NUM = r'(?:[\d,]+(?:\.\d+)?%?|N/A|NA|-|--|\*)'
rowre = re.compile(r'^\s*(?P<st>%s|%s|%s)\s+(?P<name>[A-Za-z][A-Za-z .\'`’/\-()]*?[A-Za-z.)])\s*\*?\s+(?P<nums>%s(?:\s+%s)*)\s*$' % ('|'.join(ST), OTHER, full, NUM, NUM))
out=[]
for f in sorted(glob.glob('fc/txt/*.layout.txt')):
    doc=os.path.basename(f).split('.')[0]
    page=1
    for ln,line in enumerate(open(f,errors='replace')):
        if '\f' in line:
            page += line.count('\f'); line=line.replace('\f','')
        m=rowre.match(line)
        if not m: continue
        st=m['st']; st=ST.get(st, st)
        out.append(dict(doc=doc,page=page,line=ln+1,state=st,county=m['name'].strip(),nums=m['nums'].split(),raw=line.rstrip()))
json.dump(out,open('fc/rows.json','w'))
print(len(out))
