import json, re, pandas as pd
R=pd.read_csv('fc/fullcmp.csv',dtype=str,keep_default_na=False)
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str,keep_default_na=False)
norm=lambda s: re.sub(r'[^A-Z]','',s.upper())
matched=set(zip(R.doc,R.state,R.county))
um=p[[ (a,b,c) not in matched for a,b,c in zip(p.doc_id,p.state,p.county)]]
NUMT=r'(?:[\d,]+(?:\.\d+)?%?|N/A)'
ABBR={'Alabama':'AL','Florida':'FL','Georgia':'GA','Louisiana':'LA','Mississippi':'MS','North Carolina':'NC','South Carolina':'SC','Tennessee':'TN','Texas':'TX','Virginia':'VA'}
cache={}
out=[]
for r in um.itertuples():
    if r.doc_id not in cache:
        cache[r.doc_id]=open(f'fc/txt/{r.doc_id}.layout.txt',errors='replace').read().replace('\f','\n<<PAGE>>\n').split('\n')
    L=cache[r.doc_id]; target=norm(r.county)
    found=None
    for i,l in enumerate(L):
        m=re.match(r'^(.*?)\s+(%s(?:\s+%s){2,})\s*$'%(NUMT,NUMT),l)
        if not m: continue
        lead=re.sub(r'^\s*(%s|%s)\b'%(ABBR[r.state],r.state),'',m[1])
        frags=[L[j] for j in range(i-2,i+3) if 0<=j<len(L) and j!=i and not re.search(r'\d',L[j]) and 0<len(L[j].strip())<40]
        cand=[lead]+[lead+f for f in frags]+[f+lead for f in frags]+[a+lead+b for a in frags for b in frags if a!=b]
        cand2=[norm(re.sub(r'\b(%s)\b'%ABBR[r.state],'',c)) for c in cand]
        if target in cand2 and target:
            page=1+sum(1 for x in L[:i] if x=='<<PAGE>>')
            found=dict(nums=m[2].split(),page=page,line=i+1); break
    out.append((r,found))
cols=['sites_served','sites_out','pct_out','out_damage','out_transport','out_power','on_backup_power']
bad=0;nf=0;res=[]
for r,f in out:
    if not f: nf+=1; print('NOTFOUND',r.doc_id,r.state,r.county); continue
    n=f['nums']
    vals=[n[0],n[1],n[2]]+(n[3:7] if len(n)>=6 else [])
    if len(n)==5: vals=[n[0],n[3],n[4]]
    for c,v in zip(cols,vals):
        pv=getattr(r,c)
        ok = pv!='' and abs(float(v.replace(',','').replace('%',''))-float(pv))<1e-9
        res.append(dict(doc=r.doc_id,state=r.state,county=r.county,fips=r.fips,field=c,panel=pv,mine=v,status='ok' if ok else 'diff',page=f['page']))
        if not ok: bad+=1; print('DIFF',r.doc_id,r.county,c,pv,v,f)
    # check panel has blanks where no column
    for c in cols[len(vals):]:
        if getattr(r,c)!='': print('EXTRA',r.doc_id,r.county,c,getattr(r,c))
pd.DataFrame(res).to_csv('fc/wrapcmp.csv',index=False)
print('unmatched',len(um),'notfound',nf,'diffs',bad)
