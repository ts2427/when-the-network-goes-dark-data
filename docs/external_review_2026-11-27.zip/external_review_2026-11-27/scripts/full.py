import json, re, pandas as pd, collections
rows=json.load(open('fc/rows.json'))
# Debby fallback: no state column
ST={'Florida','Georgia','South Carolina','North Carolina','Alabama','Mississippi','Louisiana','Texas','Virginia','Tennessee'}
NUM=r'(?:[\d,]+(?:\.\d+)?%?|N/A)'
for d in ['DOC-404487A1']:
    cur=None; page=1
    for ln,line in enumerate(open(f'fc/txt/{d}.layout.txt',errors='replace')):
        page+=line.count('\f'); line=line.replace('\f','')
        m=re.match(r'^\s*(%s)\s*:?\s*$'%'|'.join(ST),line)
        if m: cur=m[1]; continue
        m=re.match(r'^\s*([A-Z][A-Za-z .\'-]*?[a-z.])\s+(%s(?:\s+%s){2,})\s*$'%(NUM,NUM),line)
        if m and cur and m[1].strip().upper()!='TOTAL':
            rows.append(dict(doc=d,page=page,line=ln+1,state=cur,county=m[1].strip(),nums=m[2].split(),raw=line.rstrip()))
json.dump(rows,open('fc/rows2.json','w'))
def num(t):
    t=t.replace(',','').replace('%','')
    try: return float(t)
    except: return None
norm=lambda s: re.sub(r'[^A-Z]','',s.upper())
mine={}
for r in rows:
    n=r['nums']; k=len(n)
    if k==5: f=dict(served=n[0],out=n[3],pct=n[4])
    elif k>=3:
        f=dict(served=n[0],out=n[1],pct=n[2])
        if k>=6: f.update(D=n[3],T=n[4],P=n[5])
        if k==7: f['B']=n[6]
        if k==4 or k>7: f['odd']=k
    else: continue
    key=(r['doc'],r['state'],norm(r['county']))
    if key in mine: mine[key]['dup']=True
    mine[key]=dict(f,page=r['page'],raw=r['raw'],ntok=k)
json.dump({'|'.join(k):v for k,v in mine.items()},open('fc/mine.json','w'))
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str,keep_default_na=False)
cols=dict(served='sites_served',out='sites_out',pct='pct_out',D='out_damage',T='out_transport',P='out_power',B='on_backup_power')
res=[];unmatched=[]
for r in p.itertuples():
    key=(r.doc_id,r.state,norm(r.county))
    m=mine.get(key)
    if not m: unmatched.append(key); continue
    for f,c in cols.items():
        pv=getattr(r,c); mv=m.get(f)
        if mv is None and pv=='' : st='both_blank'
        elif mv is None: st='panel_only'
        elif pv=='': st='mine_only:'+mv
        else:
            a=num(mv); b=num(pv)
            if a is None: st='nonnum:'+mv
            elif f=='pct': st='ok' if abs(a-b)<0.051 else 'diff'
            else: st='ok' if a==b else 'diff'
        res.append(dict(doc=r.doc_id,state=r.state,county=r.county,fips=r.fips,field=f,panel=pv,mine=mv,status=st,page=m['page'],pct_printed=r.pct_printed,raw=m['raw']))
R=pd.DataFrame(res); R.to_csv('fc/fullcmp.csv',index=False)
print(len(unmatched), unmatched[:10])
print(R.groupby(['field','status']).size().to_string())
