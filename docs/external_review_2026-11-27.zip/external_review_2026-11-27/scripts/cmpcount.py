import json, pandas as pd, collections
rows=json.load(open('fc/rows.json'))
ST10={'Alabama','Florida','Georgia','Louisiana','Mississippi','North Carolina','South Carolina','Tennessee','Texas','Virginia'}
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str)
pc=p.groupby('doc_id').size()
mc=collections.Counter(r['doc'] for r in rows if r['state'] in ST10)
man=pd.read_csv('code/manifest/dirs_reports.csv',dtype=str)
for _,r in man.iterrows():
    d=r.doc_id; a=pc.get(d,0); b=mc.get(d,0)
    if a!=b: print(d,r.storm_name,r.report_date,r.status,'panel',a,'mine',b)
print(len(p), p.fips.nunique(), p.doc_id.nunique(), p.storm_key.nunique())
