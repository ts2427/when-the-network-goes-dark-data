import pandas as pd,re
c=pd.read_csv('data/input/census/national_county2020.txt',sep='|',dtype=str)
SN={'AL':'Alabama','FL':'Florida','GA':'Georgia','LA':'Louisiana','MS':'Mississippi','NC':'North Carolina','SC':'South Carolina','TN':'Tennessee','TX':'Texas','VA':'Virginia'}
c=c[c.STATE.isin(SN)]
def n(s):
    s=s.upper().replace('`',"'")
    s=re.sub(r'\b(COUNTY|PARISH)\b','',s)
    s=re.sub(r'\bSAINT\b','ST',s)
    return re.sub(r'[^A-Z]','',s)
idx={}
for r in c.itertuples():
    nm=r.COUNTYNAME; key=(SN[r.STATE],n(nm)); f=r.STATEFP+r.COUNTYFP
    idx.setdefault(key,[]).append((f,nm))
p=pd.read_csv('data/analysis/dirs_county_day.csv',dtype=str,keep_default_na=False)
u=p[['state','county','fips']].drop_duplicates()
issues=[]
for r in u.itertuples():
    cands=idx.get((r.state,n(r.county)),[])
    fs=[f for f,_ in cands]
    if len(cands)==1 and fs[0]==r.fips: continue
    issues.append((r.state,r.county,r.fips,cands))
for i in issues: print(i)
print(len(u),len(issues))
